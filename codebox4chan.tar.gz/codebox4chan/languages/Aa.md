> <h3> Available Languages </h3>
>
> - en.lang = English-US 🇺🇲
> - vi.lang = Vietnamese 🇻🇳
> - tl.lang = Tagalog 🇵🇭
> - bs.lang = Bisaya/Cebuano 🇵🇭
> - bd.lang = Bengali 🇧🇩
> - ar.lang = Arabic 🇸🇦🇦🇪
